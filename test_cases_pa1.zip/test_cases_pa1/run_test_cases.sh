#!/bin/bash

interpreter=$(which python3)
test_cases=$1

if [[ "$test_cases" == "mining" || "$test_cases" == "validating" ]]; then
    if [[ ! -e  $test_cases.bin ]]; then
        echo "Error: Test case binary does not exist";
        exit 1
    fi
    $interpreter $test_cases.bin
else
    echo "Incorrect argument";
fi